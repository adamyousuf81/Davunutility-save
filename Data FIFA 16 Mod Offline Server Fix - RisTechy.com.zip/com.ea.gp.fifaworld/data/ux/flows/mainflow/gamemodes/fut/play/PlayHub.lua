local fut_livetiles_service, eventmanager, Timer, VirtualButton, FeatureTileModel, TableUtil = ...
local liveTilesType = fut_livetiles_service.FE.UXService.FUTLiveTilesType
local PlayHub = {}
local bndOnlineSeasons = "bnd_online_seasons"
local bndOfflineTournaments = "bnd_offline_tournaments"
local bndOfflineSeasons = "bnd_offline_seasons"
local bndofflineSeasonsEnabled = "bnd_offline_seasons_enabled"
local bndonlineSeasonsEnabled = "bnd_online_seasons_enabled"
local bndofflineTournamentsEnabled = "bnd_offline_tournaments_enabled"
local bndofflineTournamentsLoading = "bnd_offline_tournaments_loading"
local bndAccomplishmentsTile = "bnd_live_tile_accomplishments"
local BND_OFFLINE_PROGRESS_BAR_DATA = "bnd_offline_progress_bar_data"
local BND_ONLINE_PROGRESS_BAR_DATA = "bnd_online_progress_bar_data"
local ACT_TO_OFFLINE_TOURNAMENTS = "act_to_offline_tournaments"
local EventTypes = eventmanager.FE.FIFA.EventTypes
function PlayHub:new(init)
  local o = init or {}
  setmetatable(o, self)
  self.__index = self
  o.services = {
    FUTTournamentService = o.api("FUTTournamentService"),
    liveTilesService = o.api("FUTLiveTilesService"),
    SeasonService = o.api("SeasonService"),
    EventManService = o.api("EventManagerService"),
    PowService = o.api("PowService")
  }
  o.models = {
    FeatureTileModel = FeatureTileModel:new({
      im = o.im,
      api = o.api,
      loc = o.loc,
      nav = o.nav,
      viewType = "simple",
      imageScale = 0.7
    })
  }
  o.handlerId = o.services.EventManService.RegisterHandler(function(...)
    o:handleEvent(...)
  end)
  o.liveTileTimer = 1
  o.timesLoaded = 1
  o.im.Subscribe(bndOnlineSeasons, function()
    o:_publishSeason(bndOnlineSeasons)
  end)
  o.im.Subscribe(bndOfflineSeasons, function()
    o:_publishSeason(bndOfflineSeasons)
  end)
  o.im.Subscribe(BND_ONLINE_PROGRESS_BAR_DATA, function()
    o:_publishProgressBarData(BND_ONLINE_PROGRESS_BAR_DATA, o.onlineSeasonInfo)
  end)
  o.im.Subscribe(BND_OFFLINE_PROGRESS_BAR_DATA, function()
    o:_publishProgressBarData(BND_OFFLINE_PROGRESS_BAR_DATA, o.offlineSeasonInfo)
  end)
  o.im.Subscribe(bndOfflineTournaments, function()
    o:_publishOfflineTournament()
  end)
  o.im.Subscribe(bndAccomplishmentsTile, function()
    o:_publishAccomplishments()
  end)
  o.im.Subscribe(bndofflineTournamentsEnabled, function()
    o.im.Publish(bndofflineTournamentsEnabled, true)
  end)
  o.im.Subscribe(bndofflineSeasonsEnabled, function()
    local seasonEnabled = o.services.SeasonService.IsOfflineSeasonEnabled()
    o.im.Publish(bndofflineSeasonsEnabled, seasonEnabled)
  end)
  o.im.Subscribe(bndonlineSeasonsEnabled, function()
    local seasonEnabled = o.services.SeasonService.IsOnlineSeasonEnabled()
    o.im.Publish(bndonlineSeasonsEnabled, seasonEnabled)
  end)
  
  o.onlineSeasonInfo = {}
  o.offlineSeasonInfo = {}
  o.services.liveTilesService.RetrieveData()
  
  o.hasTournamentsAvailable = true
  o.im.RegisterAction(ACT_TO_OFFLINE_TOURNAMENTS, function(actionName)
    if o.hasTournamentsAvailable == true then
      o.nav.Event(nil, "evt_to_offline_tournaments")
    end
  end)
  
  return o
end

function PlayHub:_loadSeasons()
  if self.onlineSeasonInfo.seasonID == nil then
    self.services.SeasonService.LoadSeasons(true)
  elseif self.offlineSeasonInfo.seasonID == nil then
    self.services.SeasonService.LoadSeasons(true)
  end
end

function PlayHub:_onSeasonLoaded(data)
  if data.isOnline then
    self.onlineSeasonInfo = self.services.SeasonService.GetCachedSeasonInfo(true)
    self:_publishSeason(bndOnlineSeasons)
    self:_publishProgressBarData(BND_ONLINE_PROGRESS_BAR_DATA, self.onlineSeasonInfo)
  else
    self.offlineSeasonInfo = self.services.SeasonService.GetCachedSeasonInfo(false)
    self:_publishSeason(bndOfflineSeasons)
    self:_publishProgressBarData(BND_OFFLINE_PROGRESS_BAR_DATA, self.offlineSeasonInfo)
  end
  self:_loadSeasons()
end
function PlayHub:_publishSeason(binding)
  local button = {}
  local seasonInfo
  if binding == bndOnlineSeasons then
    button.headline = {
      self.loc.LocalizeString("LTXT_LT_LIVE_TILE_ONLINE_SEASONS")
    }
    button.images = {
      "$FUTHubPlayOnlineSeasons"
    }
    seasonInfo = self.services.SeasonService.GetCachedSeasonInfo(true)
  elseif binding == bndOfflineSeasons then
    button.headline = {
      self.loc.LocalizeString("LTXT_FUT_LIVE_TILE_OFFLINE_SEASONS")
    }
    button.images = {
      "$FUTHubPlayOfflineSeasons"
    }
    seasonInfo = self.services.SeasonService.GetCachedSeasonInfo(false)
  else
    return
  end
  if seasonInfo ~= nil and seasonInfo.division ~= nil then
    button.feedback = {
      label = self.loc.LocalizeString("LTXT_PLAY_LIVE_TILE_DIV"),
      value = self.loc.LocalizeInteger(seasonInfo.division)
    }
    if seasonInfo.seasonID ~= nil and seasonInfo.seasonID >= 0 then
      button.feedback.subFeedbacks = {
        {
          label = self.loc.LocalizeString("LTXT_PLAY_LIVE_TILE_POINTS"),
          value = self.loc.LocalizeInteger(seasonInfo.points)
        },
        {
          label = self.loc.LocalizeString("LTXT_PLAY_LIVE_TILE_GAMES_REMAINING"),
          value = self.loc.LocalizeInteger(seasonInfo.gamesRemaining)
        }
      }
      if 0 <= seasonInfo.projection then
        table.insert(button.feedback.subFeedbacks, 2, {
          label = self.loc.LocalizeString("LTXT_PLAY_LIVE_TILE_PROJECTION"),
          value = self.loc.LocalizeInteger(seasonInfo.projection)
        })
      end
    end
  end
  if binding ~= nil then
    self.im.Publish(binding, button)
  end
end
function PlayHub:_publishProgressBarData(binding, seasonInfo)
  local data = {}
  if seasonInfo ~= nil then
    if seasonInfo.trohpyPoints ~= nil then
      data.totalSteps = math.floor(seasonInfo.trohpyPoints * 10 / 9)
    end
    data.lastPoints = 0
    if seasonInfo.seasonID ~= nil and 0 <= seasonInfo.seasonID then
      data.currentPoints = seasonInfo.points
    else
      data.currentPoints = -1
    end
    data.pointsLabel = self.loc.LocalizeString("FUT_POINTS_ABBR")
    data.relegationLabel = self.loc.LocalizeString("LTXT_SEA_RELEGATION")
    if seasonInfo.heldPoints ~= nil then
      data.relegationPoints = seasonInfo.heldPoints - 1
    end
    data.projectionPoints = seasonInfo.projection
    data.promotionPoints = seasonInfo.promotionPoints
    data.promotionLabel = self.loc.LocalizeString("LTXT_SEA_PROMOTION")
    data.championshipPoints = seasonInfo.trohpyPoints
    data.championshipLabel = self.loc.LocalizeString("LTXT_SEA_CHAMPIONSHIP")
    data.division = seasonInfo.division
    data.divisionLabel = self.loc.LocalizeString("LTXT_SEA_DIV")
  end
  if data ~= nil then
    self.im.Publish(binding, data)
  end
end
function PlayHub:_publishOfflineTournament()
  local infoStats = self.services.liveTilesService.GetViewData_FUTHUB_OFFLINE_TOURNAMENT_STATS()
  local button = {
    headline = {
      self.loc.LocalizeString("LTXT_FUT_LIVE_TILE_OFFLINE_TOURNAMENT")
    },
    images = {
      "$FUTHubPlayOfflineTournament"
    }
  }
  if infoStats.tournamentAvailable then
    local infoTournament = self.services.FUTTournamentService.GetOfflineTournamentInfo(infoStats.tournamentID)
    if infoTournament ~= nil and infoTournament.available == true then
      button.description = infoTournament.tournamentName
    end
  end
  self.im.Publish(bndOfflineTournaments, button)
end
function PlayHub:_publishAccomplishments()
  local button = {
    headline = {
      self.loc.LocalizeString("LTXT_CMN_ACCOMPLISHMENTS")
    },
    subHeadline = {
      self.loc.LocalizeString("LTXT_PLAY_MORE_EARN_MORE")
    },
    images = {
      "$_FeatureAccomplishmentsLiveTile"
    }
  }
  self.im.Publish(bndAccomplishmentsTile, button)
end
function PlayHub:handleEvent(eventType, data)
  if eventType == EventTypes.OnCurrentSeasonLoaded then
    self:_onSeasonLoaded(data)
  elseif eventType == EventTypes.HubDataCallback then
    self.isHubLoaded = true
    self:_loadSeasons()
    self:_publishOfflineTournament()
    self.services.FUTTournamentService.LoadTournaments()
  elseif eventType == EventTypes.FUTTournamentListLoaded then
    self.hasTournamentsAvailable = data.hasTournamentsAvailable
    self.im.Publish(bndofflineTournamentsEnabled, self.hasTournamentsAvailable and self.services.FUTTournamentService.IsOfflineTournamentsKillSwitchOn() == true)
    self.im.Publish(bndofflineTournamentsLoading, true)
    self:_publishOfflineTournament()
  elseif eventType == EventTypes.OnSeasonLoaded then
    self.services.SeasonService.LoadCurrentSeason(data.isOnline, false)
  end
end

function PlayHub:finalize()
  self.models.FeatureTileModel:finalize()
  self.services.EventManService.UnregisterHandler(self.handlerId)
  self.im.UnregisterAction(ACT_TO_OFFLINE_TOURNAMENTS)
  self.im.Unsubscribe(bndOnlineSeasons)
  self.im.Unsubscribe(bndofflineTournamentsEnabled)
  self.im.Unsubscribe(bndofflineTournamentsLoading)
  self.im.Unsubscribe(bndAccomplishmentsTile)
  self.im.Unsubscribe(bndOfflineTournaments)
  self.im.Unsubscribe(bndofflineSeasonsEnabled)
  self.im.Unsubscribe(bndonlineSeasonsEnabled)
  self.im.Unsubscribe(bndOfflineSeasons)
  self.im.Unsubscribe(BND_ONLINE_PROGRESS_BAR_DATA)
  self.im.Unsubscribe(BND_OFFLINE_PROGRESS_BAR_DATA)
end
return PlayHub